package proje;

public abstract class OdemeYontemi {

	public abstract boolean odemeYap(double tutar);
}
