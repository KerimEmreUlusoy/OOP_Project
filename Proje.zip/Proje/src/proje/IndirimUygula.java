package proje;

public interface IndirimUygula {
    double uygula(double tutar);
    double getIndirimOrani(double tutar);
}
