package proje;

public class KademeliIndirim implements IndirimUygula {

    @Override
    public double uygula(double tutar) {
        double oran = getIndirimOrani(tutar);
        return tutar * (1 - oran);
    }

    @Override
    public double getIndirimOrani(double tutar) {
        if (tutar >= 50000) {
            return 0.20;
        } else if (tutar >= 10000) {
            return 0.10;
        } else {
            return 0.0;
        }
    }
}

