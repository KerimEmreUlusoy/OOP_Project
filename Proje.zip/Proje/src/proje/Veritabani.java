package proje;

import java.sql.*;
import java.util.ArrayList;

public class Veritabani {

    private static final String DB_URL = "jdbc:sqlite:veritabani.db";

    public static ArrayList<Urun> urunleriGetir() {
        ArrayList<Urun> urunler = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM urunler")) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String isim = rs.getString("isim");
                double fiyat = rs.getDouble("fiyat");
                String kategori = rs.getString("kategori");

                urunler.add(new Urun(id, isim, fiyat, kategori));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return urunler;
    }
}


