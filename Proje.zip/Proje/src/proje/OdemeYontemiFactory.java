package proje;

public class OdemeYontemiFactory {
    public static OdemeYontemi odemeYontemiOlustur(String tip) {
        if (tip.equalsIgnoreCase("kredi")) {
            return new KrediKartiOdeme();
        }
        return null;
    }
}
