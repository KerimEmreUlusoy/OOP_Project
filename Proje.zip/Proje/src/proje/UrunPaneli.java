package proje;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class UrunPaneli extends JPanel {
    private JComboBox<String> kategoriBox;
    private JList<Urun> urunListesi;
    private DefaultListModel<Urun> urunModel;

    private JList<Urun> favoriListesi;
    private DefaultListModel<Urun> favoriModel;

    private JTabbedPane tabbedPane;

    public UrunPaneli() {
        setLayout(new BorderLayout());

        tabbedPane = new JTabbedPane();

        // Kategorili sekme
        JPanel kategoriPanel = new JPanel(new BorderLayout());

        ArrayList<Urun> tumUrunler = Veritabani.urunleriGetir();
        ArrayList<String> kategoriler = new ArrayList<>();
        for (Urun u : tumUrunler) {
            if (u.getKategori() != null && !kategoriler.contains(u.getKategori())) {
                kategoriler.add(u.getKategori());
            }
        }

        kategoriBox = new JComboBox<>(kategoriler.toArray(new String[0]));
        kategoriBox.addActionListener(e -> kategoriyeGoreFiltrele());

        urunModel = new DefaultListModel<>();
        urunListesi = new JList<>(urunModel);
        JScrollPane urunScroll = new JScrollPane(urunListesi);

        kategoriPanel.add(kategoriBox, BorderLayout.NORTH);
        kategoriPanel.add(urunScroll, BorderLayout.CENTER);

        tabbedPane.addTab("Kategoriler", kategoriPanel);

        // Favoriler sekmesi
        JPanel favoriPanel = new JPanel(new BorderLayout());

        favoriModel = new DefaultListModel<>();
        favoriListesi = new JList<>(favoriModel);
        JScrollPane favoriScroll = new JScrollPane(favoriListesi);

        favoriPanel.add(favoriScroll, BorderLayout.CENTER);
        tabbedPane.addTab("Sevilenler", favoriPanel);

        add(tabbedPane, BorderLayout.CENTER);
        setBorder(BorderFactory.createTitledBorder("Ürünler"));

        if (!kategoriler.isEmpty()) {
            kategoriBox.setSelectedIndex(0);
            kategoriyeGoreFiltrele();
        }

        favorileriYukle();
    }

    private void kategoriyeGoreFiltrele() {
        String secilenKategori = (String) kategoriBox.getSelectedItem();
        ArrayList<Urun> urunler = Veritabani.urunleriGetir();

        urunModel.clear();
        for (Urun u : urunler) {
            if (u.getKategori() != null && u.getKategori().equals(secilenKategori)) {
                urunModel.addElement(u);
            }
        }
    }

    private void favorileriYukle() {
        ArrayList<Urun> urunler = Veritabani.urunleriGetir();

        favoriModel.clear();
        for (Urun u : urunler) {
            if (u.getIsim().equals("Gaming Mouse") ||
                u.getIsim().equals("Erkek Deri Ceket") ||
                u.getIsim().equals("Makyaj Paleti") ||
                u.getIsim().equals("Akıllı Saat") ||
                u.getIsim().equals("Bluetooth Hoparlör")) {
                favoriModel.addElement(u);
            }
        }
    }

    public Urun getSecilenUrun() {
        int seciliSekme = tabbedPane.getSelectedIndex();
        if (seciliSekme == 0) {
            return urunListesi.getSelectedValue(); // Kategoriler sekmesi
        } else {
            return favoriListesi.getSelectedValue(); // Sevilenler sekmesi
        }
    }
}





