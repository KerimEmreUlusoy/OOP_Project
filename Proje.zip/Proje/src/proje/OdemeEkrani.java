package proje;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.*;
import java.awt.*;
import java.util.List;

public class OdemeEkrani extends JFrame {
    private JTextField kartNumarasiField;
    private JTextField sonKullanmaField;
    private JTextField cvvField;
    private JTextField adSoyadField;

    private final double toplamTutar;
    private final double indirimliTutar;
    private final double indirimOrani;

    public OdemeEkrani(JFrame parent, List<Urun> sepetListesi) {
        setTitle("Ödeme Ekranı");
        setSize(400, 360);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        IndirimUygula indirim = new KademeliIndirim();

        toplamTutar = hesaplaToplam(sepetListesi);
        indirimliTutar = indirim.uygula(toplamTutar);
        indirimOrani = indirim.getIndirimOrani(toplamTutar);
        double indirimTutari = toplamTutar * indirimOrani;

        JPanel bilgiPanel = new JPanel(new GridLayout(3, 1));
        bilgiPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));
        bilgiPanel.add(new JLabel("Toplam Tutar: ₺" + toplamTutar));
        bilgiPanel.add(new JLabel("İndirim (" + (int) (indirimOrani * 100) + "%): ₺" + indirimTutari));
        bilgiPanel.add(new JLabel("Ödenecek Tutar: ₺" + indirimliTutar));
        add(bilgiPanel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        kartNumarasiField = new JTextField(16);
        sonKullanmaField = new JTextField(5);
        cvvField = new JTextField(3);
        adSoyadField = new JTextField(20);

        addRow(formPanel, gbc, 0, "Kart Numarası:", kartNumarasiField);
        addRow(formPanel, gbc, 1, "Son Kullanma (MM/YY):", sonKullanmaField);
        addRow(formPanel, gbc, 2, "CVV:", cvvField);
        addRow(formPanel, gbc, 3, "Ad Soyad:", adSoyadField);

        add(formPanel, BorderLayout.CENTER);

        JButton odemeButton = new JButton("Ödeme Yap");
        odemeButton.setPreferredSize(new Dimension(150, 30));
        JPanel btnPanel = new JPanel();
        btnPanel.add(odemeButton);
        add(btnPanel, BorderLayout.SOUTH);

        kartFormatEkle(kartNumarasiField);
        tarihFormatEkle(sonKullanmaField);
        adSoyadFormatEkle(adSoyadField);

        // ✅ Form kontrolü burada
        odemeButton.addActionListener(e -> {
            String kartNo = kartNumarasiField.getText().replaceAll("\\s", "");
            String tarih = sonKullanmaField.getText();
            String cvv = cvvField.getText();
            String adSoyad = adSoyadField.getText().trim();

            if (kartNo.isEmpty() || tarih.isEmpty() || cvv.isEmpty() || adSoyad.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Lütfen tüm alanları doldurun!", "Hata", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!kartNo.matches("\\d{16}")) {
                JOptionPane.showMessageDialog(this, "Kart numarası 16 haneli olmalıdır!", "Hata", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!tarih.matches("\\d{2}/\\d{2}")) {
                JOptionPane.showMessageDialog(this, "Tarih formatı MM/YY şeklinde olmalıdır!", "Hata", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int ay = Integer.parseInt(tarih.substring(0, 2));
            if (ay < 1 || ay > 12) {
                JOptionPane.showMessageDialog(this, "Ay bilgisi 01 ile 12 arasında olmalıdır!", "Hata", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!cvv.matches("\\d{3,4}")) {
                JOptionPane.showMessageDialog(this, "CVV 3 veya 4 haneli sayı olmalıdır!", "Hata", JOptionPane.ERROR_MESSAGE);
                return;
            }

            JOptionPane.showMessageDialog(this, "Ödeme başarılı! Teşekkürler.", "Başarılı", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        });
    }

    private void addRow(JPanel panel, GridBagConstraints gbc, int row, String label, JTextField field) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.fill = GridBagConstraints.NONE;
        panel.add(new JLabel(label), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        field.setPreferredSize(new Dimension(180, 25));
        panel.add(field, gbc);
    }

    private double hesaplaToplam(List<Urun> sepet) {
        return sepet.stream().mapToDouble(Urun::getFiyat).sum();
    }

    private void kartFormatEkle(JTextField field) {
        ((AbstractDocument) field.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                    throws BadLocationException {
                String current = fb.getDocument().getText(0, fb.getDocument().getLength());
                StringBuilder updated = new StringBuilder(current);
                updated.replace(offset, offset + length, text);
                String digits = updated.toString().replaceAll("\\D", "").substring(0,
                        Math.min(16, updated.toString().replaceAll("\\D", "").length()));

                StringBuilder formatted = new StringBuilder();
                for (int i = 0; i < digits.length(); i++) {
                    if (i > 0 && i % 4 == 0) formatted.append(" ");
                    formatted.append(digits.charAt(i));
                }

                fb.replace(0, fb.getDocument().getLength(), formatted.toString(), attrs);
            }
        });
    }

    private void tarihFormatEkle(JTextField field) {
        ((AbstractDocument) field.getDocument()).setDocumentFilter(new DocumentFilter() {
            @Override
            public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
                    throws BadLocationException {
                String current = fb.getDocument().getText(0, fb.getDocument().getLength());
                StringBuilder updated = new StringBuilder(current);
                updated.replace(offset, offset + length, text);
                String digits = updated.toString().replaceAll("\\D", "").substring(0,
                        Math.min(4, updated.toString().replaceAll("\\D", "").length()));

                StringBuilder formatted = new StringBuilder();
                for (int i = 0; i < digits.length(); i++) {
                    if (i == 2) formatted.append("/");
                    formatted.append(digits.charAt(i));
                }

                fb.replace(0, fb.getDocument().getLength(), formatted.toString(), attrs);
            }
        });
    }

    private void adSoyadFormatEkle(JTextField field) {
        field.getDocument().addDocumentListener(new DocumentListener() {
            private boolean isAdjusting = false;

            @Override
            public void insertUpdate(DocumentEvent e) { format(); }
            @Override
            public void removeUpdate(DocumentEvent e) { format(); }
            @Override
            public void changedUpdate(DocumentEvent e) {}

            private void format() {
                if (isAdjusting) return;
                isAdjusting = true;

                SwingUtilities.invokeLater(() -> {
                    String input = field.getText();
                    int caret = field.getCaretPosition();

                    StringBuilder sb = new StringBuilder();
                    boolean nextUpper = true;

                    for (int i = 0; i < input.length(); i++) {
                        char c = input.charAt(i);
                        if (Character.isWhitespace(c)) {
                            sb.append(c);
                            nextUpper = true;
                        } else {
                            sb.append(nextUpper ? Character.toUpperCase(c) : Character.toLowerCase(c));
                            nextUpper = false;
                        }
                    }

                    String formatted = sb.toString();
                    if (!input.equals(formatted)) {
                        field.setText(formatted);
                        field.setCaretPosition(Math.min(caret, formatted.length()));
                    }

                    isAdjusting = false;
                });
            }
        });
    }
}










