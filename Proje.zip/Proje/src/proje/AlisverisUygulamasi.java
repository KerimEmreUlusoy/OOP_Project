package proje;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class AlisverisUygulamasi extends JFrame {
    private UrunPaneli urunPaneli;
    private DefaultListModel<Urun> sepetModel;

    public AlisverisUygulamasi() {
        setLookAndFeel();
        setTitle("J-SHOP - Online Alışveriş");
        setSize(700, 450);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        urunPaneli = new UrunPaneli();

        sepetModel = new DefaultListModel<>();
        JList<Urun> sepetList = new JList<>(sepetModel);
        JScrollPane sepetScroll = new JScrollPane(sepetList);
        sepetScroll.setBorder(BorderFactory.createTitledBorder("Sepet"));

        JButton sepeteEkle = new JButton("Sepete Ekle");
        sepeteEkle.setBackground(new Color(173, 216, 230));
        sepeteEkle.setForeground(Color.BLACK);
        sepeteEkle.addActionListener(e -> {
            Urun secilen = urunPaneli.getSecilenUrun();
            if (secilen != null) {
                sepetModel.addElement(secilen);
            }
        });

        JButton sepettenCikar = new JButton("Sepetten Çıkar");
        sepettenCikar.setBackground(new Color(173, 216, 230));
        sepettenCikar.setForeground(Color.BLACK);
        sepettenCikar.addActionListener(e -> {
            Urun secilen = sepetList.getSelectedValue();
            if (secilen != null) {
                sepetModel.removeElement(secilen);
            }
        });

        JButton odemeYap = new JButton("Ödeme Yap");
        odemeYap.setBackground(new Color(100, 180, 255));
        odemeYap.setForeground(Color.WHITE);
        odemeYap.addActionListener(e -> {
            if (sepetModel.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Sepet boş!", "Uyarı", JOptionPane.WARNING_MESSAGE);
                return;
            }

            List<Urun> sepetListesi = new ArrayList<>();
            for (int i = 0; i < sepetModel.size(); i++) {
                sepetListesi.add(sepetModel.getElementAt(i));
            }

            new OdemeEkrani(this, sepetListesi).setVisible(true);
        });

        JPanel butonPanel = new JPanel(new FlowLayout());
        butonPanel.setBackground(new Color(230, 240, 255));
        butonPanel.add(sepeteEkle);
        butonPanel.add(sepettenCikar);
        butonPanel.add(odemeYap);

        add(urunPaneli, BorderLayout.WEST);
        add(sepetScroll, BorderLayout.CENTER);
        add(butonPanel, BorderLayout.SOUTH);
    }

    private void setLookAndFeel() {
        UIManager.put("Panel.background", new Color(230, 240, 255));
        UIManager.put("List.background", new Color(240, 248, 255));
        UIManager.put("List.selectionBackground", new Color(173, 216, 230));
        UIManager.put("List.selectionForeground", Color.BLACK);
        UIManager.put("Button.background", new Color(173, 216, 230));
        UIManager.put("Button.foreground", Color.BLACK);
        UIManager.put("ComboBox.background", new Color(230, 240, 255));
        UIManager.put("ComboBox.foreground", Color.BLACK);
        UIManager.put("ScrollPane.background", new Color(230, 240, 255));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new AlisverisUygulamasi().setVisible(true);
        });
    }
}










