package proje;

public class KrediKartiOdeme extends OdemeYontemi {
    @Override
    public boolean odemeYap(double tutar) {
        System.out.println("₺" + tutar + " tutarında kredi kartıyla ödeme yapıldı.");
        return true;
    }
}
