package proje;

public class Urun {
    private int id;
    private String isim;
    private double fiyat;
    private String kategori;

    public Urun(int id, String isim, double fiyat, String kategori) {
        this.id = id;
        this.isim = isim;
        this.fiyat = fiyat;
        this.kategori = kategori;
    }

    public int getId() {
        return id;
    }

    public String getIsim() {
        return isim;
    }

    public double getFiyat() {
        return fiyat;
    }

    public String getKategori() {
        return kategori;
    }

    @Override
    public String toString() {
        return isim + " - " + fiyat + " TL (" + kategori + ")";
    }
}




